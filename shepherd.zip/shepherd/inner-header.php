<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="zxx">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Home | Himalayan Shepherds</title>

    <script src="js/aXeeT3C8FEVE2uMUPMMUDxVnKrs.js"></script>
    <link rel="shortcut icon" type="image/x-icon" href="images/logo1.png">

    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

    <link href="css/style.css" rel="stylesheet" type="text/css">

    <link href="font/flaticon.css" rel="stylesheet" type="text/css">

    <link href="css/plugin.css" rel="stylesheet" type="text/css">

    <link rel="stylesheet"
          href="css/font-awesome.min.css">
</head>
<body>

<div id="preloader">
    <div id="status"></div>
</div>


<header>
    <div class="upper-head clearfix">
        <div class="container">
            <div class="contact-info">
                <p><i class="flaticon-phone-call"></i> Phone: (012)-345-6789</p>
                <p><i class="flaticon-mail"></i> Mail: <a href="https://cyclonethemes.com/cdn-cgi/l/email-protection"
                                                          class="__cf_email__"
                                                          data-cfemail="097d667c7b677d7b687f6c65497d6c7a7d64686065276a6664">[email&#160;protected]</a>
                </p>
            </div>
            <div class="login-btn pull-right">
                <!--<a href="login.html"><i class="fa fa-user-plus"></i> Register</a>-->
                <!--<a href="login.html"><i class="fa fa-unlock-alt"></i> Login</a>-->
            </div>
        </div>
    </div>
</header>


<div class="navigation">
    <div class="container">
        <div class="navigation-content">
            <div class="header_menu">

                <nav class="navbar navbar-default navbar-sticky-function navbar-arrow">
                    <div class="logo pull-left">
                        <a href="index.php"><img alt="Image" src="images/Yatra-01.png"></a>
                    </div>
                    <div id="navbar" class="navbar-nav-wrapper">
                        <ul class="nav navbar-nav" id="responsive-menu">
                                <li class="active">
                                    <a href="index.php">Home</a>
                                </li>
                                <li>
                                    <a href="aboutus.php">About Us <i class="fa fa-angle-down"></i></a>
                                    <ul>
                                        <li><a href="#">Our Team</a>
                                        <li><a href="#">Our Story</a>
                                        <li><a href="#">Our Community Support</a>
                                        <li><a href="#">Media Coverage</a>
                                        <li><a href="#">Why Climb With Us</a>
                                    </ul>
                                </li>
                                <li>
                                    <a href="tour.php">Expedition <i class="fa fa-angle-down"></i></a>
                                    <ul>
                                        <li><a href="tour-detail.php">Packages Detail</a>
                                        <li><a href="#">Packages</a>
                                        <li><a href="#">Packages</a>
                                    </ul>
                                </li>
                                <li>
                                    <a href="tour.php">Trekking & Tour<i class="fa fa-angle-down"></i></a>
                                    <ul>
                                        <li><a href="tour-detail.php">Packages Detail</a>
                                        <li><a href="#">Packages</a>
                                        <li><a href="#">Packages</a>
                                    </ul>
                                </li>
                                <li>
                                    <a href="tour.php">Themed Package <i class="fa fa-angle-down"></i></a>
                                    <ul>
                                        <li><a href="tour-detail.php">Packages Detail</a>
                                        <li><a href="#">Packages</a>
                                        <li><a href="#">Packages</a>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#">CSR</a>
                                </li>
                                <li>
                                    <a href="contact.php">Contact Us</a>
                                </li>
                            </ul>
                    </div>
                    <div id="slicknav-mobile"></div>
                </nav>
            </div>
        </div>
    </div>
</div>


