<?php include('header.php')?>

<section id="home_banner_video" class="banner-style-1">
    <div class="video-banner">
        <video autoplay loop muted playsinline src="images/video.mp4" type="video/mp4">

        </video>
    </div>
    <div class="video-banner-content">
        <div class="js_frm_subscribe">
            <div class="kenburns_061_slide slider-content">
                <h1>You Have Been Never Closer to heaven NEPAL</h1>
                <h2>exeperience the himalaya with us</h2>
                <a href="tour-detail.php" class="btn-blue btn-red btn-style-1">Learn more</a>
            </div>
        </div>
    </div>
</section>


<div class="search-box clearfix bg-white">
    <div class="container">
        <div class="search-outer">
            <div class="search-content">
                <form>
                    <div class="row">
                        <div class="col-md-3 col-xs-6">
                            <div class="table_item">
                                <div class="form-group">
                                    <select name="custom-select-1" class="selectpicker form-control" tabindex="1">
                                        <option value="0">Destination</option>
                                        <option value="1">0</option>
                                        <option value="2">1</option>
                                        <option value="3">2</option>
                                        <option value="4">3</option>
                                        <option value="5">4</option>
                                    </select>
                                    <i class="flaticon-maps-and-flags"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-6">
                            <div class="table_item">
                                <div class="form-group">
                                    <select name="custom-select-2" class="selectpicker form-control" tabindex="1">
                                        <option value="0">Type</option>
                                        <option value="1">0</option>
                                        <option value="2">1</option>
                                        <option value="3">2</option>
                                        <option value="4">3</option>
                                        <option value="5">4</option>
                                    </select>
                                    <i class="flaticon-box"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-6">
                            <div class="table_item">
                                <div class="form-group">
                                    <div class='input-group date' id='datetimepicker1'>
                                        <input type='text' class="form-control" value="dd-mm-yyyy" />
                                        <i class="flaticon-calendar"></i>
                                        <span class="input-group-addon">
<i class="fa fa-calendar" aria-hidden="true"></i>
</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-xs-6">
                            <div class="table_item">
                                <div class="search">
                                    <a href="#" class="btn-blue btn-red btn-style-1">SEARCH</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<section class="amazing-tours">
    <div class="container">
        <div class="section-title text-center">
            <h2>Amazing Tours</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Duis aute irure dolor in reprehenderit..</p>
        </div>
        <div class="row">
            <div class="col-md-6 col-xs-12">
                <div class="at-item box-item">
                    <div class="at-image">
                        <img src="images/at2.jpg" alt="Image">
                        <div class="at-overlay"></div>
                    </div>
                    <div class="at-content">
                        <h3><a href="#">Italy</a></h3>
                        <span>The colosseum</span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-xs-6">
                <div class="at-item box-item">
                    <div class="at-image">
                        <img src="images/at1.jpg" alt="Image">
                        <div class="at-overlay"></div>
                    </div>
                    <div class="at-content">
                        <h3><a href="#">Brazil</a></h3>
                        <span>The colosseum</span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-xs-6">
                <div class="at-item box-item">
                    <div class="at-image">
                        <img src="images/at3.jpg" alt="Image">
                        <div class="at-overlay"></div>
                    </div>
                    <div class="at-content">
                        <h3><a href="#">Venezuela</a></h3>
                        <span>The colosseum</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3 col-xs-6">
                <div class="at-item box-item">
                    <div class="at-image">
                        <img src="images/at1.jpg" alt="Image">
                        <div class="at-overlay"></div>
                    </div>
                    <div class="at-content">
                        <h3><a href="#">Kenya</a></h3>
                        <span>The colosseum</span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-xs-6">
                <div class="at-item box-item">
                    <div class="at-image">
                        <img src="images/at3.jpg" alt="Image">
                        <div class="at-overlay"></div>
                    </div>
                    <div class="at-content">
                        <h3><a href="#">Greece</a></h3>
                        <span>The colosseum</span>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-xs-12">
                <div class="at-item box-item">
                    <div class="at-image">
                        <img src="images/at2.jpg" alt="Image">
                        <div class="at-overlay"></div>
                    </div>
                    <div class="at-content">
                        <h3><a href="#">Iceland</a></h3>
                        <span>The colosseum</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="deals">
    <div class="container">
        <div class="section-title section-title-white text-center">
            <h2>Last Minute Deals</h2>
            <div class="section-icon">
                <i class="flaticon-diamond"></i>
            </div>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                dolore magna aliqua.Duis aute irure dolor in reprehenderit..</p>
        </div>
        <div class="deals-outer">
            <div class="row deals-slider slider-button">
                <div class="col-md-3">
                    <div class="deals-item">
                        <div class="deals-item-outer">
                            <div class="deals-image">
                                <img src="images/deal1.jpg" alt="Image">
                                <span class="deal-price">$8600</span>
                            </div>
                            <div class="deal-content">
                                <div class="deal-rating">
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star-o"></span>
                                    <span class="fa fa-star-o"></span>
                                </div>
                                <h3>Paris and Bordeaus</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.</p>
                                <a href="tour-detail.html" class="btn-blue btn-red">More Details</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="deals-item">
                        <div class="deals-item-outer">
                            <div class="deals-image">
                                <img src="images/deal2.jpg" alt="Image">
                                <span class="deal-price">$8600</span>
                            </div>
                            <div class="deal-content">
                                <div class="deal-rating">
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star-o"></span>
                                    <span class="fa fa-star-o"></span>
                                </div>
                                <h3>Paris and Bordeaus</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.</p>
                                <a href="tour-detail.html" class="btn-blue btn-red">More Details</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="deals-item">
                        <div class="deals-item-outer">
                            <div class="deals-image">
                                <img src="images/deal3.jpg" alt="Image">
                                <span class="deal-price">$8600</span>
                            </div>
                            <div class="deal-content">
                                <div class="deal-rating">
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star-o"></span>
                                    <span class="fa fa-star-o"></span>
                                </div>
                                <h3>Paris and Bordeaus</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.</p>
                                <a href="tour-detail.html" class="btn-blue btn-red">More Details</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="deals-item">
                        <div class="deals-item-outer">
                            <div class="deals-image">
                                <img src="images/deal4.jpg" alt="Image">
                                <span class="deal-price">$8600</span>
                            </div>
                            <div class="deal-content">
                                <div class="deal-rating">
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star-o"></span>
                                    <span class="fa fa-star-o"></span>
                                </div>
                                <h3>Paris and Bordeaus</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.</p>
                                <a href="tour-detail.html" class="btn-blue btn-red">More Details</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="deals-item">
                        <div class="deals-item-outer">
                            <div class="deals-image">
                                <img src="images/deal2.jpg" alt="Image">
                                <span class="deal-price">$8600</span>
                            </div>
                            <div class="deal-content">
                                <div class="deal-rating">
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star-o"></span>
                                    <span class="fa fa-star-o"></span>
                                </div>
                                <h3>Paris and Bordeaus</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.</p>
                                <a href="tour-detail.html" class="btn-blue btn-red">More Details</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="deals-item">
                        <div class="deals-item-outer">
                            <div class="deals-image">
                                <img src="images/deal1.jpg" alt="Image">
                                <span class="deal-price">$8600</span>
                            </div>
                            <div class="deal-content">
                                <div class="deal-rating">
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star-o"></span>
                                    <span class="fa fa-star-o"></span>
                                </div>
                                <h3>Paris and Bordeaus</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.</p>
                                <a href="tour-detail.html" class="btn-blue btn-red">More Details</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="deals-item">
                        <div class="deals-item-outer">
                            <div class="deals-image">
                                <img src="images/deal4.jpg" alt="Image">
                                <span class="deal-price">$8600</span>
                            </div>
                            <div class="deal-content">
                                <div class="deal-rating">
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star-o"></span>
                                    <span class="fa fa-star-o"></span>
                                </div>
                                <h3>Paris and Bordeaus</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.</p>
                                <a href="tour-detail.html" class="btn-blue btn-red">More Details</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="deals-item">
                        <div class="deals-item-outer">
                            <div class="deals-image">
                                <img src="images/deal3.jpg" alt="Image">
                                <span class="deal-price">$8600</span>
                            </div>
                            <div class="deal-content">
                                <div class="deal-rating">
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star-o"></span>
                                    <span class="fa fa-star-o"></span>
                                </div>
                                <h3>Paris and Bordeaus</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod.</p>
                                <a href="tour-detail.html" class="btn-blue btn-red">More Details</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="section-overlay"></div>
</section>

<section class="deals-on-sale">
    <div class="container">
        <div class="section-title text-center">
            <h2>Deals On Sale</h2>
            <div class="section-icon">
                <i class="flaticon-diamond"></i>
            </div>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Duis aute irure dolor in reprehenderit..</p>
        </div>
        <div class="row sale-slider slider-button">
            <div class="col-md-12">
                <div class="sale-item box-item">
                    <div class="sale-image">
                        <img src="images/sale1.jpg" alt="Image">
                    </div>
                    <div class="sale-content-1 sale-content">
                        <div class="sale-review">
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                        </div>
                        <h3><a href="#">Surfing at Bahamas</a></h3>
                        <div class="sale-content-inner">
                            <p><i class="flaticon-time"></i> 5 days</p>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>
                            <a href="tour-detail.html" class="btn-blue btn-red btn-style-1">View More</a>
                        </div>
                    </div>
                    <div class="sale-tag">
                        <span class="old-price">$1449</span>
                        <span class="new-price"> $900</span>
                    </div>
                    <div class="sale-overlay"></div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="sale-item box-item">
                    <div class="sale-image">
                        <img src="images/sale2.jpg" alt="Image">
                    </div>
                    <div class="sale-content-1 sale-content">
                        <div class="sale-review">
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                        </div>
                        <h3><a href="#">Surfing at Bahamas</a></h3>
                        <div class="sale-content-inner">
                            <p><i class="flaticon-time"></i> 5 days</p>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>
                            <a href="tour-detail.html" class="btn-blue btn-red btn-style-1">View More</a>
                        </div>
                    </div>
                    <div class="sale-tag">
                        <span class="old-price">$1449</span>
                        <span class="new-price"> $900</span>
                    </div>
                    <div class="sale-overlay"></div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="sale-item box-item">
                    <div class="sale-image">
                        <img src="images/sale3.jpg" alt="Image">
                    </div>
                    <div class="sale-content-1 sale-content">
                        <div class="sale-review">
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                        </div>
                        <h3><a href="#">Surfing at Bahamas</a></h3>
                        <div class="sale-content-inner">
                            <p><i class="flaticon-time"></i> 5 days</p>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>
                            <a href="tour-detail.html" class="btn-blue btn-red btn-style-1">View More</a>
                        </div>
                    </div>
                    <div class="sale-tag">
                        <span class="old-price">$1449</span>
                        <span class="new-price"> $900</span>
                    </div>
                    <div class="sale-overlay"></div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="sale-item box-item">
                    <div class="sale-image">
                        <img src="images/sale4.jpg" alt="Image">
                    </div>
                    <div class="sale-content-1 sale-content">
                        <div class="sale-review">
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                        </div>
                        <h3><a href="#">Surfing at Bahamas</a></h3>
                        <div class="sale-content-inner">
                            <p><i class="flaticon-time"></i> 5 days</p>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.</p>
                            <a href="tour-detail.html" class="btn-blue btn-red btn-style-1">View More</a>
                        </div>
                    </div>
                    <div class="sale-tag">
                        <span class="old-price">$1449</span>
                        <span class="new-price"> $900</span>
                    </div>
                    <div class="sale-overlay"></div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="full-tours">
    <div class="container">
        <div class="section-title text-center">
            <h2>Destination Featured</h2>
            <a href="#">View all destination <i class="fa fa-long-arrow-right"></i></a>
            <div class="back-title"><h3>Destination</h3></div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12">
            <div class="ft-item">
                <div class="ft-image">
                    <img src="images/ft1.jpg" alt="Image">
                    <div class="ft-overlay"></div>
                </div>
                <div class="ft-content">
                    <h2><a href="#">Hot Air Ballooning</a></h2>
                    <p>Starting from <span>$ 325</span></p>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6">
            <div class="ft-item">
                <div class="ft-image">
                    <img src="images/ft2.jpg" alt="Image">
                    <div class="ft-overlay"></div>
                </div>
                <div class="ft-content">
                    <h2><a href="#">Surfing at Goa</a></h2>
                    <p>Starting from <span>$ 325</span></p>
                </div>
            </div>
            <div class="ft-item">
                <div class="ft-image">
                    <img src="images/ft3.jpg" alt="Image">
                    <div class="ft-overlay"></div>
                </div>
                <div class="ft-content">
                    <h2><a href="#">Sailing Thailand</a></h2>
                    <p>Starting from <span>$ 325</span></p>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6">
            <div class="ft-item">
                <div class="ft-image">
                    <img src="images/ft4.jpg" alt="Image">
                    <div class="ft-overlay"></div>
                </div>
                <div class="ft-content">
                    <h2><a href="#">Lake Tohoe Adventure</a></h2>
                    <p>Starting from <span>$ 325</span></p>
                </div>
            </div>
            <div class="ft-item">
                <div class="ft-image">
                    <img src="images/ft5.jpg" alt="Image">
                    <div class="ft-overlay"></div>
                </div>
                <div class="ft-content">
                    <h2><a href="#">Dancing in Bali</a></h2>
                    <p>Starting from <span>$ 325</span></p>
                </div>
            </div>
        </div>
    </div>
</section>



<section class="testimonials">
    <div class="section-title text-center">
        <h2>Best Rated Travel Agency</h2>
        <div class="section-icon section-icon-white">
            <i class="flaticon-diamond"></i>
        </div>
    </div>

    <div id="testimonial_094" class="carousel slide testimonial_094_indicators thumb_scroll_x swipe_x ps_easeOutSine"
         data-ride="carousel" data-pause="hover" data-interval="3000" data-duration="1000">

        <ol class="carousel-indicators">
            <li data-target="#testimonial_094" data-slide-to="0" class="active">
                <img src="images/testemonial1.jpg" alt="testimonial_094_01">
            </li>
            <li data-target="#testimonial_094" data-slide-to="1">
                <img src="images/testemonial2.jpg" alt="testimonial_094_02">
            </li>
            <li data-target="#testimonial_094" data-slide-to="2">
                <img src="images/testemonial3.jpg" alt="testimonial_094_03">
            </li>
            <li data-target="#testimonial_094" data-slide-to="3">
                <img src="images/testemonial4.jpg" alt="testimonial_094_04">
            </li>
            <li data-target="#testimonial_094" data-slide-to="4">
                <img src="images/testemonial5.jpg" alt="testimonial_094_05">
            </li>
        </ol>

        <div class="carousel-inner" role="listbox">

            <div class="item active">

                <div class="testimonial_094_slide">
                    <p>Lorem ipsum dolor sit amet consectetuer adipiscing elit am nibh unc varius facilisis eros ed erat
                        in in velit quis arcu ornare laoreet urabitur adipiscing luctus massa nteger ut purus ac augue
                        commodo commodo unc nec mi eu justo tempor consectetuer tiam.</p>
                    <div class="deal-rating">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star-o"></span>
                        <span class="fa fa-star-o"></span>
                    </div>
                    <h5><a href="#">Susan Doe, Houston</a></h5>
                </div>
            </div>


            <div class="item">

                <div class="testimonial_094_slide">
                    <p>Lorem ipsum dolor sit amet consectetuer adipiscing elit am nibh unc varius facilisis eros ed erat
                        in in velit quis arcu ornare laoreet urabitur adipiscing luctus massa nteger ut purus ac augue
                        commodo commodo unc nec mi eu justo tempor consectetuer tiam.</p>
                    <div class="deal-rating">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star-o"></span>
                        <span class="fa fa-star-o"></span>
                    </div>
                    <h5><a href="#">Susan Doe, Houston</a></h5>
                </div>
            </div>


            <div class="item">

                <div class="testimonial_094_slide">
                    <p>Lorem ipsum dolor sit amet consectetuer adipiscing elit am nibh unc varius facilisis eros ed erat
                        in in velit quis arcu ornare laoreet urabitur adipiscing luctus massa nteger ut purus ac augue
                        commodo commodo unc nec mi eu justo tempor consectetuer tiam.</p>
                    <div class="deal-rating">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star-o"></span>
                        <span class="fa fa-star-o"></span>
                    </div>
                    <h5><a href="#">Susan Doe, Houston</a></h5>
                </div>
            </div>


            <div class="item">

                <div class="testimonial_094_slide">
                    <p>Lorem ipsum dolor sit amet consectetuer adipiscing elit am nibh unc varius facilisis eros ed erat
                        in in velit quis arcu ornare laoreet urabitur adipiscing luctus massa nteger ut purus ac augue
                        commodo commodo unc nec mi eu justo tempor consectetuer tiam.</p>
                    <div class="deal-rating">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star-o"></span>
                        <span class="fa fa-star-o"></span>
                    </div>
                    <h5><a href="#">Susan Doe, Houston</a></h5>
                </div>
            </div>


            <div class="item">

                <div class="testimonial_094_slide">
                    <p>Lorem ipsum dolor sit amet consectetuer adipiscing elit am nibh unc varius facilisis eros ed erat
                        in in velit quis arcu ornare laoreet urabitur adipiscing luctus massa nteger ut purus ac augue
                        commodo commodo unc nec mi eu justo tempor consectetuer tiam.</p>
                    <div class="deal-rating">
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star checked"></span>
                        <span class="fa fa-star-o"></span>
                        <span class="fa fa-star-o"></span>
                    </div>
                    <h5><a href="#">Susan Doe, Houston</a></h5>
                </div>
            </div>

        </div>
    </div>
</section>


<section class="countdown-section">
    <div class="container">
        <div class="countdown-title">
            <h2>Special Tour in May, Discover <span>Thailand</span> for 50 Customers with <span>Discount 30%</span></h2>
            <p>It’s limited seating! Hurry up</p>
        </div>
        <div class="countdown countdown-container container">
            <p id="demo"></p>
        </div>
    </div>
    <div class="testimonial-overlay"></div>
</section>


<section class="top-destinations-1">
    <div class="container">
        <div class="section-title text-center">
            <h2>Trending Activities</h2>
            <a href="#">View all trending <i class="fa fa-long-arrow-right"></i></a>
            <div class="back-title"><h3>Trending</h3></div>
        </div>
        <div class="row">
            <div class="col-md-4 col-sm-12">
                <div class="destination-item-1 box-item">
                    <div class="destination-image-1">
                        <img src="images/destination-fw1.jpg" alt="Image">
                    </div>
                    <div class="destination-content-1">
                        <h3><a href="tour-detail.html">5-Day Oahu Tour: Honolulu, Pearl Harbor</a></h3>
                        <p class="package-days1"><i class="flaticon-time"></i> 5 days</p>
                        <div class="deal-rating">
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star-o"></span>
                            <span class="fa fa-star-o"></span>
                        </div>
                        <div class="tour-price">
                            <span class="tour-head">From</span>
                            <span class="tour-tail">$1,500</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-6">
                <div class="destination-item-1 box-item">
                    <div class="destination-image-1">
                        <img src="images/destination-fw2.jpg" alt="Image">
                    </div>
                    <div class="destination-content-1">
                        <h3><a href="tour-detail.html">Molokini and Turtle Arches Snorkeling Trip</a></h3>
                        <p class="package-days1"><i class="flaticon-time"></i> 2 days</p>
                        <div class="deal-rating">
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star-o"></span>
                            <span class="fa fa-star-o"></span>
                        </div>
                        <div class="tour-price">
                            <span class="tour-head">From</span>
                            <span class="tour-tail">$500</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-6">
                <div class="destination-item-1 box-item">
                    <div class="destination-image-1">
                        <img src="images/destination-fw3.jpg" alt="Image">
                        <div class="thumbnail-ribbon">
                            <span>Best Seller</span>
                        </div>
                    </div>
                    <div class="destination-content-1">
                        <h3><a href="tour-detail.html">Turkey Tour: A Cultural & Historical Journey</a></h3>
                        <p class="package-days1"><i class="flaticon-time"></i> 2 days</p>
                        <div class="deal-rating">
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star-o"></span>
                            <span class="fa fa-star-o"></span>
                        </div>
                        <div class="tour-price">
                            <span class="tour-head">From</span>
                            <span class="tour-tail">$2,500</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include('footer.php')?>